﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp;
using CsvHelper;
using CsvHelper.Configuration;
using File = ConsoleApp.File;
namespace SRS
{
    internal class Program
    {
      
    
        public class Test
        {
            public static object A { get; private set; }

            public static void Main(string[] args)
            {
                string[,] newArray = new string[50, 10];
                File file = new File();
                Calculator cal = new Calculator();
                file.ReadFile("C:\\Users\\94753\\Documents\\RUSHDHA.csv", newArray);
                int noOfCol = cal.CalColumns(newArray);

                newArray[0, Calculator.bestSubjectCol] = "Best Subject";
                newArray[0, Calculator.totalCol] = "Total";
                newArray[0, Calculator.rankCol] = "Rank";

                for (int i = 1; i < cal.CalColumns(newArray); i++)
                {
                    newArray[i, Calculator.bestSubjectCol] = cal.BestSubject(newArray, i);
                    newArray[i, Calculator.totalCol] = cal.Total(newArray, i);
                }

                cal.Sort(newArray, Calculator.totalCol);
                cal.Rank(newArray, Calculator.rankCol);

                for (int i = 0; i < newArray.GetLength(0); i++)
                {
                    for (int j = 0; j < newArray.GetLength(1); j++)
                    {
                        Console.Write("{0} ", newArray[i, j]);
                    }
                    Console.WriteLine();
                }

                file.WriteFile("C:\\Users\\94753\\Documents\\SRS\\report.csv", newArray, cal.CalColumns(newArray));
               String filePath = @"C:\\Users\\94753\\Documents\\SRS\\report.csv";
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while((line = reader.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();

               
            }
            }

        }
      
    }

    

namespace ConsoleApp
{
    public class File
    {
        public void ReadFile(string path, string[,] arr)
        {
            StreamReader streamReader = new StreamReader(path);
            CsvReader csvReader = new CsvReader(streamReader, CultureInfo.CurrentCulture);

            string value;
            int j = 0;
            while (csvReader.Read())
            {
                for (int i = 0; csvReader.TryGetField<string>(i, out value); i++)
                {
                    arr[j, i] = value;
                }
                j++;
            }
        }
        public void WriteFile(string path, string[,] arr, int col)
        {
            StreamWriter streamWriter = new StreamWriter(path);
            CsvWriter csvWriter = new CsvWriter(streamWriter, CultureInfo.InvariantCulture);


            for (int i = 0; i < col; i++)
            {
                csvWriter.WriteField(arr[i, 0]);
                csvWriter.WriteField(arr[i, Calculator.rankCol]);
                csvWriter.WriteField(arr[i, Calculator.bestSubjectCol]);
                csvWriter.NextRecord();
            }

            csvWriter.Dispose();
            streamWriter.Dispose();
        }
    }
}

namespace ConsoleApp
{
    public class Calculator
    {
        public static int bestSubjectCol = 9;
        public static int totalCol = 8;
        public static int rankCol = 7;

        public string Total(string[,] arr, int colomn)
        {

            return Convert.ToString((Convert.ToInt32(arr[colomn, 1])
                + Convert.ToInt32(arr[colomn, 2])
                + Convert.ToInt32(arr[colomn, 3])
                + Convert.ToInt32(arr[colomn, 4])));
        }

        public void Sort(string[,] arr, int col)
        {
            int inside, outside;
            string[] tempArr = new string[10];
            for (outside = 2; outside < CalColumns(arr); outside++) 
            {
                for (int i = 0; i < arr.GetLength(1); i++)
                    tempArr[i] = arr[outside, i]; 

                inside = outside; 
                while (inside > 1 && Convert.ToInt32(arr[inside - 1, col]) <= Convert.ToInt32(tempArr[col])) 
                {
                    for (int i = 0; i < arr.GetLength(1); i++)
                        arr[inside, i] = arr[inside - 1, i]; 
                }
                for (int i = 0; i < arr.GetLength(1); i++)
                    arr[inside, i] = tempArr[i];
            }
        }

        public string BestSubject(string[,] arr, int colomn)
        {
            int max = 0, count = 0;
            for (int i = 1; i < arr.GetLength(1) - 3; i++)
            {
                int value = Convert.ToInt32(arr[colomn, i]);
                if (max < value)
                {
                    max = value;
                    count = i;
                }
            }
            return arr[0, count];
        }

        public void Rank(string[,] arr, int col)
        {
            for (int i = 1; i < CalColumns(arr); i++)
            {
                arr[i, col] = Convert.ToString(i);
            }
        }

        public int CalColumns(string[,] arr)
        {
            int i;
            for (i = 0; i < arr.GetLength(0); i++)
            {
                if (arr[i, 0] == null)
                    break;

            }
            return i;
        }

    }
}

